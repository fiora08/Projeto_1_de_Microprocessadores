// // #include <avr/io.h>
// #include <avr/interrupt.h>
// #include "timers.h"
// #include "teclado.h"
// #include "lcd.h"
// #include "energia.h"
// 
// 
// int main(void) {
// 	// 1. Inicializa��es de Hardware
// 	teclado_inicializar(); // Configura PORTA
// 	timer0_init();         // Configura base de 1ms
// 	energia_inicializar(); // Define estado inicial como DESLIGADO
// 	
// 	// Habilita interrup��es globais para o Timer 0
// 	sei();
// 	
// 	while (1) {
// 		// A fun��o energia_gerenciar cuida do cron�metro de 3s e 4s
// 		energia_gerenciar();
// 
// 		// S� processamos o eco do teclado se o sistema estiver ativo
// 		if (energia_sistema_ativo() == LIGADO) {
// 			
// 			// O teclado_atualizar processa o debounce de 20ms
// 			teclado_atualizar();
// 			unsigned char tecla_pressionada = teclado_obter_tecla();
// 			
// 			if (tecla_pressionada != 0) {
// 				lcd_caractere(tecla_pressionada);
// 			}
// 		}
// 		// LIMPEZA DA FLAG: Essencial para que energia e teclado vejam o mesmo "tique"
// 		if (flag_1ms) {
// 			flag_1ms = 0;
// 		}
// 	}
// }
#include <avr/io.h>
#include <avr/interrupt.h>
#include "timers.h"
#include "serial.h"
#include "lcd.h"
#include "teclado.h"
#include "energia.h"

int main(void) {
	// Inicializa��es padr�o do sistema
	serial_inicializar(51); // 19200 bps @ 16MHz com Paridade Par
	timer0_init();
	timer1_init();
	teclado_inicializar();
	lcd_inicializar();
	energia_inicializar();
	
	sei(); // Habilita interrup��es para o buffer RX e Timers

	char tecla;
	char buffer_lcd[17];
	uint8_t index = 0;
	uint8_t sistema_ja_ligado = 0;

	while (1) {
		// Monitora o bot�o 'D' (segurar 3s) no PICSimLab para ligar
		energia_gerenciar();

		if (energia_sistema_ativo() == LIGADO) {
			
			// --- MENSAGEM DE STATUS (Roda uma vez ao ligar) ---
			if (!sistema_ja_ligado) {
				lcd_limpar();
				lcd_posicionar(0, 0);
				lcd_escrever_string("MicPay 2026");
				lcd_posicionar(1, 0);
				lcd_escrever_string("Sistema Ativo");
				sistema_ja_ligado = 1;
			}

			// --- SELE��O 1: QUEM ESCUTA (Hercules -> PICSimLab) ---
			// A serial monitora se voc� enviou algo pelo Hercules
			if (serial_disponivel()) {
				char recebido = serial_ler();
				
				// Exibe no LCD o que veio do PC
				if (recebido == '\n' || index >= 16) {
					buffer_lcd[index] = '\0';
					lcd_limpar();
					lcd_posicionar(0, 0);
					lcd_escrever_string(buffer_lcd);
					index = 0;
					} else {
					buffer_lcd[index++] = recebido;
				}
			}

			// --- SELE��O 2: QUEM FALA (PICSimLab -> Hercules) ---
			// Verifica se voc� clicou no teclado do simulador
			teclado_atualizar();
			tecla = teclado_obter_tecla();
			
			if (tecla != 0) {
				// O Arduino "toma a palavra" e envia para o Hercules
				serial_transmitir(tecla);
				
				// Feedback visual na linha 2
				lcd_posicionar(1, 0);
				lcd_escrever_string("Teclado: ");
				lcd_caractere(tecla);
			}
			
			flag_1ms = 0; // Reset para o pr�ximo ciclo de debounce
			} else {
			sistema_ja_ligado = 0;
		}
	}
	return 0;
}