#ifndef ENERGIA_H
#define ENERGIA_H

// Estados poss�veis do sistema MicPay
#define DESLIGADO 0
#define LIGADO    1

// Prot�tipos das fun��es
void energia_inicializar(void);
void energia_gerenciar(void);
unsigned char energia_sistema_ativo(void);

#endif
