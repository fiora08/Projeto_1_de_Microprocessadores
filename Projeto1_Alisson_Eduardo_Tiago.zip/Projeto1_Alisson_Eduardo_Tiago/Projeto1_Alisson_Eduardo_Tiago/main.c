// // #include <avr/io.h>
// #include <avr/interrupt.h>
// #include "timers.h"
// #include "teclado.h"
// #include "lcd.h"
// #include "energia.h"
// 
// 
// int main(void) {
// 	// 1. Inicializa��es de Hardware
// 	teclado_inicializar(); // Configura PORTA
// 	timer0_init();         // Configura base de 1ms
// 	energia_inicializar(); // Define estado inicial como DESLIGADO
// 	
// 	// Habilita interrup��es globais para o Timer 0
// 	sei();
// 	
// 	while (1) {
// 		// A fun��o energia_gerenciar cuida do cron�metro de 3s e 4s
// 		energia_gerenciar();
// 
// 		// S� processamos o eco do teclado se o sistema estiver ativo
// 		if (energia_sistema_ativo() == LIGADO) {
// 			
// 			// O teclado_atualizar processa o debounce de 20ms
// 			teclado_atualizar();
// 			unsigned char tecla_pressionada = teclado_obter_tecla();
// 			
// 			if (tecla_pressionada != 0) {
// 				lcd_caractere(tecla_pressionada);
// 			}
// 		}
// 		// LIMPEZA DA FLAG: Essencial para que energia e teclado vejam o mesmo "tique"
// 		if (flag_1ms) {
// 			flag_1ms = 0;
// 		}
// 	}
// }
#include <avr/io.h>
#include <avr/interrupt.h>
#include "timers.h"
#include "serial.h"
#include "lcd.h"
#include "teclado.h"
#include "energia.h"

int main(void) {
	// Inicializa��o dos perif�ricos
	serial_inicializar(51); -> formula para dar o 119200 com 16 mhz foi definido o 51 para a velocidade baud. 
	timer0_init();
	timer1_init();
	teclado_inicializar();
	lcd_inicializar();
	energia_inicializar();
	
	sei(); // Habilita interrup��es

	char tecla;
	char buffer_lcd[17]; // 16 caracteres + '\0'
	uint8_t index = 0;
	uint8_t sistema_ja_ligado = 0;

	while (1) {
		energia_gerenciar(); //

		if (energia_sistema_ativo() == LIGADO) {
			
			// --- INICIALIZA��O VISUAL ---
			if (!sistema_ja_ligado) {
				lcd_limpar(); //
				lcd_posicionar(0, 2); // Centraliza levemente "MicPay 2026"
				lcd_escrever_string("MicPay 2026");
				lcd_posicionar(1, 1);
				lcd_escrever_string("Sistema Ativo");
				sistema_ja_ligado = 1;
			}

			// --- ESCUTA SERIAL (LINHA 0) ---
			if (serial_disponivel()) {
				char recebido = serial_ler();
				
				// Trata Enter ou limite de 16 colunas do LCD
				if (recebido == '\n' || recebido == '\r' || index >= 16) {
					buffer_lcd[index] = '\0';
					
					// Limpa apenas a linha 0 para novos dados da serial
					lcd_posicionar(0, 0);
					lcd_escrever_string("� � � � � � � � "); // 16 espa�os para limpar
					lcd_posicionar(0, 0);
					lcd_escrever_string(buffer_lcd);
					index = 0;
					} else {
					buffer_lcd[index++] = recebido;
				}
			}

			// --- FALA TECLADO (LINHA 1) ---
			teclado_atualizar(); //
			tecla = teclado_obter_tecla();
			
			if (tecla != 0) {
				serial_transmitir(tecla);
				
				// Limpa a parte de dados da linha 1 (coluna 9 em diante)
				lcd_posicionar(1, 0);
				lcd_escrever_string("Teclado:� � � � "); // Mant�m o r�tulo e limpa o resto
				lcd_posicionar(1, 9);
				lcd_caractere(tecla); //
			}
			
			flag_1ms = 0; //
			} else {
			sistema_ja_ligado = 0;
		}
	}
	return 0;
}